FEMITECH EMPIRE — SELECTED WORKS ASSET PACK

Contents:
00-selected-works-overview.png — combined overview of all six portfolio categories
01-graphics-design.png — graphics design showcase (updated WhatsApp number; no website link)
02-website-design.png — website design showcase
03-video-editing.png — video editing showcase
04-ai-content-creation.png — AI content creation showcase
05-digital-ads.png — digital advertising showcase
06-book-design.png — book design showcase

Brand contact shown on applicable designs: +234 815 591 8065
Brand: FEMITECH EMPIRE — Creative Digital Agency
Tagline: WE TURN IDEAS INTO DIGITAL EXPERIENCES

IMPORTANT:
These are AI-generated portfolio concept visuals/mockups created for the FEMITECH EMPIRE website.
Present them as concept work or sample showcases, not as verified client commissions or completed customer projects.
Review all small text in each image before publishing; AI-generated images can contain minor text inaccuracies.
